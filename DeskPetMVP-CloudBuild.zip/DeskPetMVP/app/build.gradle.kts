plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.pan.deskpet"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.pan.deskpet"
        minSdk = 26
        targetSdk = 33
        versionCode = 1
        versionName = "0.1.0"
    }
}
