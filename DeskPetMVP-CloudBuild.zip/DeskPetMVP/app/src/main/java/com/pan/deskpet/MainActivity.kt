package com.pan.deskpet

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("deskpet", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        }
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        // Rebuild on return so the permission/status text stays current.
        if (Build.VERSION.SDK_INT >= 23 && Settings.canDrawOverlays(this)) {
            // Nothing else required; UI actions remain available.
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(26), dp(22), dp(24))
            setBackgroundColor(Color.rgb(249, 247, 255))
        }
        val title = TextView(this).apply {
            text = "桌面宠物 · MVP"
            textSize = 26f
            setTextColor(Color.rgb(43, 35, 61))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        root.addView(title)
        val subtitle = TextView(this).apply {
            text = "先验证悬浮、拖拽、换装与桌面漫游。当前自带的是示例占位角色，后续可替换为真人风格透明素材。"
            textSize = 14f
            setTextColor(Color.rgb(93, 84, 111))
            setPadding(0, dp(10), 0, dp(20))
        }
        root.addView(subtitle)
        root.addView(button("显示 / 启动桌面宠物") { startPet() })
        root.addView(button("停止桌面宠物") {
            stopService(Intent(this, PetOverlayService::class.java))
            Toast.makeText(this, "桌面宠物已停止", Toast.LENGTH_SHORT).show()
        })
        val wardrobeTitle = TextView(this).apply {
            text = "换装（示例服装）"
            textSize = 18f
            setTextColor(Color.rgb(43, 35, 61))
            setPadding(0, dp(22), 0, dp(8))
        }
        root.addView(wardrobeTitle)
        root.addView(button("01 · 都会深色套装") { changeOutfit(0) })
        root.addView(button("02 · 复古绿调套装") { changeOutfit(1) })
        root.addView(button("03 · 紫色幻想套装") { changeOutfit(2) })
        root.addView(button("切换：桌面自主漫游 开 / 关") {
            val enabled = !prefs.getBoolean("wander", false)
            prefs.edit().putBoolean("wander", enabled).apply()
            sendPetAction(PetOverlayService.ACTION_WANDER, enabled)
            Toast.makeText(this, if (enabled) "自主漫游已开启" else "自主漫游已关闭", Toast.LENGTH_SHORT).show()
        })
        val note = TextView(this).apply {
            text = "使用提示：首次启动需允许“显示在其他应用上层”。拖动宠物可改变位置；轻点宠物可返回本控制页。"
            textSize = 13f
            setTextColor(Color.rgb(100, 91, 115))
            setPadding(0, dp(18), 0, 0)
        }
        root.addView(note)
        setContentView(root)
    }

    private fun button(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 15f
        setOnClickListener { action() }
        val params = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52))
        params.topMargin = dp(5)
        layoutParams = params
    }

    private fun startPet() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(intent)
            Toast.makeText(this, "请在设置中允许悬浮窗权限，然后返回再点一次启动", Toast.LENGTH_LONG).show()
            return
        }
        val intent = Intent(this, PetOverlayService::class.java).setAction(PetOverlayService.ACTION_START)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        Toast.makeText(this, "桌面宠物已启动", Toast.LENGTH_SHORT).show()
    }

    private fun changeOutfit(index: Int) {
        prefs.edit().putInt("outfit", index).apply()
        sendPetAction(PetOverlayService.ACTION_OUTFIT, index)
        Toast.makeText(this, "已选择第 ${index + 1} 套服装", Toast.LENGTH_SHORT).show()
    }

    private fun sendPetAction(action: String, value: Any) {
        val intent = Intent(this, PetOverlayService::class.java).setAction(action)
        when (value) {
            is Int -> intent.putExtra(PetOverlayService.EXTRA_OUTFIT, value)
            is Boolean -> intent.putExtra(PetOverlayService.EXTRA_WANDER, value)
        }
        try { startService(intent) } catch (_: Exception) { /* Service may not be running yet. */ }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
