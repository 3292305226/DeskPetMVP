package com.pan.deskpet

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView

class PetOverlayService : Service() {
    companion object {
        const val ACTION_START = "com.pan.deskpet.START"
        const val ACTION_OUTFIT = "com.pan.deskpet.OUTFIT"
        const val ACTION_WANDER = "com.pan.deskpet.WANDER"
        const val EXTRA_OUTFIT = "outfit"
        const val EXTRA_WANDER = "wander"
        private const val CHANNEL_ID = "deskpet_running"
        private const val NOTIFICATION_ID = 501
    }

    private lateinit var windowManager: WindowManager
    private var petView: ImageView? = null
    private var params: WindowManager.LayoutParams? = null
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("deskpet", MODE_PRIVATE) }
    private var outfit = 0
    private var wandering = false
    private var velocityX = 2.2f
    private var velocityY = 0.0f
    private var lastTouchX = 0f
    private var lastTouchY = 0f
    private var downX = 0f
    private var downY = 0f
    private var dragging = false
    private var lastMoveAt = 0L

    private val wanderRunnable = object : Runnable {
        override fun run() {
            val view = petView
            val lp = params
            if (view != null && lp != null && wandering && !dragging) {
                val maxX = (resources.displayMetrics.widthPixels - view.width).coerceAtLeast(0)
                val maxY = (resources.displayMetrics.heightPixels - view.height).coerceAtLeast(0)
                lp.x += velocityX.toInt().let { if (it == 0) if (velocityX >= 0) 2 else -2 else it }
                lp.y += velocityY.toInt()
                if (lp.x <= 0 || lp.x >= maxX) velocityX = -velocityX
                if (lp.y <= 0 || lp.y >= maxY) velocityY = -velocityY
                lp.x = lp.x.coerceIn(0, maxX)
                lp.y = lp.y.coerceIn(0, maxY)
                try { windowManager.updateViewLayout(view, lp) } catch (_: Exception) {}
            }
            handler.postDelayed(this, 45L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        outfit = prefs.getInt("outfit", 0).coerceIn(0, 2)
        wandering = prefs.getBoolean("wander", false)
        showPetIfNeeded()
        handler.postDelayed(wanderRunnable, 45L)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_OUTFIT -> {
                outfit = intent.getIntExtra(EXTRA_OUTFIT, outfit).coerceIn(0, 2)
                prefs.edit().putInt("outfit", outfit).apply()
                updateOutfit()
            }
            ACTION_WANDER -> {
                wandering = intent.getBooleanExtra(EXTRA_WANDER, !wandering)
                prefs.edit().putBoolean("wander", wandering).apply()
            }
            ACTION_START, null -> showPetIfNeeded()
        }
        return START_STICKY
    }

    private fun showPetIfNeeded() {
        if (petView != null) return
        val view = ImageView(this).apply {
            setImageResource(outfitDrawable(outfit))
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "桌面宠物，轻点打开控制面板，拖动可移动"
            setOnTouchListener { v, event -> handleTouch(v, event) }
        }
        val lp = WindowManager.LayoutParams(
            dp(150), dp(245),
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("x", 40).coerceAtLeast(0)
            y = prefs.getInt("y", 160).coerceAtLeast(0)
        }
        try {
            windowManager.addView(view, lp)
            petView = view
            params = lp
        } catch (_: Exception) {
            stopSelf()
        }
    }

    private fun handleTouch(view: View, event: MotionEvent): Boolean {
        val lp = params ?: return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.rawX
                downY = event.rawY
                lastTouchX = event.rawX
                lastTouchY = event.rawY
                lastMoveAt = System.currentTimeMillis()
                dragging = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - lastTouchX
                val dy = event.rawY - lastTouchY
                if (kotlin.math.abs(event.rawX - downX) > dp(5) || kotlin.math.abs(event.rawY - downY) > dp(5)) dragging = true
                if (dragging) {
                    lp.x = (lp.x + dx.toInt()).coerceAtLeast(0)
                    lp.y = (lp.y + dy.toInt()).coerceAtLeast(0)
                    try { windowManager.updateViewLayout(view, lp) } catch (_: Exception) {}
                    lastMoveAt = System.currentTimeMillis()
                }
                lastTouchX = event.rawX
                lastTouchY = event.rawY
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                prefs.edit().putInt("x", lp.x).putInt("y", lp.y).apply()
                if (!dragging) openControlPanel()
                return true
            }
        }
        return true
    }

    private fun openControlPanel() {
        val launch = packageManager.getLaunchIntentForPackage(packageName) ?: return
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        try { startActivity(launch) } catch (_: Exception) {}
    }

    private fun updateOutfit() {
        petView?.setImageResource(outfitDrawable(outfit))
    }

    private fun outfitDrawable(index: Int): Int = when (index) {
        1 -> R.drawable.pet_outfit_2
        2 -> R.drawable.pet_outfit_3
        else -> R.drawable.pet_outfit_1
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "桌面宠物运行状态", NotificationManager.IMPORTANCE_LOW).apply {
                description = "桌面宠物悬浮运行所需的通知"
            }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        val pending = PendingIntent.getActivity(this, 0, launch, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("桌面宠物正在运行")
                .setContentText("轻点通知打开换装与漫游控制")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentIntent(pending)
                .setOngoing(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("桌面宠物正在运行")
                .setContentText("轻点通知打开控制面板")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentIntent(pending)
                .setOngoing(true)
                .build()
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        handler.removeCallbacks(wanderRunnable)
        petView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        petView = null
        params = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
