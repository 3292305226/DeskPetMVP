# DeskPet MVP（安卓桌面宠物）

这是一个原生 Android/Kotlin 最小可用项目，包含：
- 悬浮宠物（需要“显示在其他应用上层”权限）
- 手指拖拽，位置保存到本地
- 三套示例服装切换，保存上次选择
- 可开关的桌面横向漫游
- 前台服务通知，减少服务被系统随意回收的概率

## 重要说明

当前 `pet_outfit_1.xml`、`pet_outfit_2.xml`、`pet_outfit_3.xml` 是**可编译的矢量占位角色**，不是最终的超写实真人素材，也不是真正的 Live2D 模型。第一版先验证悬浮窗、拖拽和换装链路。

真正的 Live2D 动态角色需要准备合法授权的 Cubism 模型资源（通常包含 `.moc3`、模型配置 JSON、纹理 PNG、动作/表情文件等），并集成 Live2D Cubism SDK for Android。不能只把一张 PNG 改名就变成 Live2D。

## 环境
- Android Studio（建议使用当前稳定版）
- JDK 17 或更新版本（Android Studio 自带的 JBR 通常可用）
- Android SDK Platform 35，以及对应 Build Tools
- 首次同步需要网络下载 Gradle 插件和依赖

## 打开并生成 APK
1. 解压 `DeskPetMVP.zip`。
2. 在 Android Studio 选择 **Open**，打开解压后的 `DeskPetMVP` 文件夹（不是只打开 `app` 文件夹）。
3. 等待 Gradle Sync 完成；如果提示安装 Android SDK 35，按提示安装。
4. 连接安卓设备并开启开发者选项/USB 调试，或启动模拟器。
5. 点击 Run 运行。首次启动后，点“显示 / 启动桌面宠物”，按系统页面提示允许悬浮窗权限，再返回应用重试。
6. 生成 APK：菜单 **Build → Build Bundle(s) / APK(s) → Build APK(s)**。
7. Debug APK 通常位于 `app/build/outputs/apk/debug/app-debug.apk`。这是 Android Studio 构建后的路径，并非本压缩包内预先生成的 APK。

## 素材替换规范
当前占位素材是 Android Vector Drawable，文件位于：
`app/src/main/res/drawable/pet_outfit_1.xml` 等。

要换成透明 PNG：
1. 将透明背景、全身、正面或轻微 3/4 视角角色图放入 `app/src/main/res/drawable-nodpi/`，建议 PNG，避免系统按屏幕密度缩放纹理。
2. 图片建议纵向比例约 2:3，角色完整留在画面内，头顶和脚底留 3%–5% 安全边距；每套服装画布尺寸、角色站姿、镜头、光照、人物比例必须一致，避免切换时跳动。
3. 文件可命名为 `pet_outfit_1.png`、`pet_outfit_2.png`、`pet_outfit_3.png`，再将 `PetOverlayService.kt` 中的 `outfitDrawable()` 改为对应的 `R.drawable.pet_outfit_1` 等资源。
4. 如果需要“分层换装”，至少需要统一画布的身体底图、头发前层/后层、上衣、下装、鞋袜、配饰等透明 PNG 图层，且各层必须严格对齐；本 MVP 的整图切换不需要这些分层。

## 当前已知限制
- 漫游目前是基础的屏幕内移动与边缘反弹，不是骨骼动画，也不识别应用窗口/刘海/挖孔区域。
- 各 Android 厂商的后台管理策略不同，可能需要把应用加入电池优化白名单。
- Android 系统权限页的入口和文案会因系统版本/厂商而不同。
- 当前项目源码已组织为标准 Android Studio 工程，但此环境没有 Android Gradle 构建工具与 Android SDK，故未在这里实际编译验证；请在 Android Studio Sync/Build 后，以构建结果为准。

## 没有电脑：使用 GitHub 云端构建（平板可操作）

项目包含 `.github/workflows/build-apk.yml`，可让 GitHub Actions 在云端编译 Debug APK。

简要流程：
1. 在浏览器打开 GitHub 并登录，创建一个新的空仓库（Repository），例如 `DeskPetMVP`。
2. 在仓库页面使用 **Add file → Upload files** 上传本项目内的所有文件和文件夹（包括隐藏目录 `.github`）。若移动浏览器无法上传文件夹，可使用 GitHub 网页编辑器先创建 `.github/workflows/build-apk.yml`，再粘贴同名工作流内容；其余源码文件需按目录结构上传。
3. 提交（Commit）到 `main` 分支后，打开仓库的 **Actions** 页面，进入 **Build Android APK** 工作流，点击 **Run workflow**（若 push 已自动触发，可直接打开最近一次运行）。
4. 等待工作流完成。绿色成功状态表示构建步骤通过；进入该次运行页面底部的 **Artifacts**，下载 `DeskPetMVP-debug-apk` 并解压得到 `app-debug.apk`。
5. 将 APK 安装到平板。首次运行需要在系统设置中允许“显示在其他应用上层”。

注意：GitHub 网页的移动版界面可能会折叠部分菜单；可在浏览器菜单中选择“桌面版网站”。云端构建仍需 GitHub 账号与网络访问。首次编译若失败，应查看 Actions 日志中的第一条实际错误；不要把“工作流已启动”当作 APK 已成功生成。
